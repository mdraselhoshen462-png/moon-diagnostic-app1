package com.moondiagnostic.app

import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val navy = Color.rgb(18,59,93)
    private val teal = Color.rgb(31,122,120)
    private val bg = Color.rgb(238,248,255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(dp(18), dp(10), dp(18), dp(12))
    }

    private fun showLogin() {
        val root = base()
        val title = TextView(this).apply {
            text = "Moon Diagnostic Center"
            textSize = 25f; setTextColor(navy); gravity = Gravity.CENTER
            setTypeface(typeface, 1); setPadding(0, dp(20), 0, dp(18))
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val user = EditText(this).apply { hint = "ইউজারনেম"; setSingleLine() }
        val pass = EditText(this).apply { hint = "পাসওয়ার্ড"; setSingleLine(); inputType = 0x81 }
        root.addView(user, lp()); root.addView(pass, lp())
        val login = Button(this).apply { text = "লগইন"; setTextColor(Color.WHITE); setBackgroundColor(teal) }
        root.addView(login, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })
        login.setOnClickListener {
            if (user.text.toString().trim().isEmpty() || pass.text.toString().isEmpty()) {
                Toast.makeText(this, "ইউজারনেম ও পাসওয়ার্ড দিন", Toast.LENGTH_SHORT).show()
            } else showDashboard(user.text.toString().trim())
        }
        setContentView(root)
    }

    private fun showDashboard(role: String) {
        val root = base()
        val roleText = TextView(this).apply {
            text = "Role: ${if (role.equals("admin", true)) "Admin" else "User"}"
            textSize = 22f; setTextColor(teal); gravity = Gravity.CENTER
        }
        root.addView(roleText, LinearLayout.LayoutParams(-1, dp(45)))
        val logout = Button(this).apply {
            text = "↪  LOGOUT"; textSize = 18f; setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(215,53,56))
        }
        root.addView(logout, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(18) })
        logout.setOnClickListener { showLogin() }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val heading = TextView(this).apply {
            text = "📊  আজকের পরিসংখ্যান"; textSize = 28f; setTextColor(navy)
            setTypeface(typeface,1); gravity=Gravity.CENTER; setPadding(0,dp(12),0,dp(12))
        }
        content.addView(heading)

        val grid1 = grid()
        addCard(grid1,"📋","মোট সিরিয়াল"){ showList("all") }
        addCard(grid1,"⌛","অপেক্ষমাণ"){ showList("waiting") }
        addCard(grid1,"✅","সম্পন্ন"){ showList("completed") }
        addCard(grid1,"❌","বাতিল"){ showList("cancelled") }
        content.addView(grid1)

        val fast = TextView(this).apply {
            text="⚡  দ্রুত অ্যাকশন"; textSize=27f; setTextColor(navy); setTypeface(typeface,1)
            gravity=Gravity.CENTER; setPadding(0,dp(22),0,dp(12))
        }
        content.addView(fast)
        val grid2=grid()
        addCard(grid2,"📋","টোটাল সিরিয়াল"){ showList("all") }
        addCard(grid2,"➕","অ্যাড সিরিয়াল"){ addSerial() }
        addCard(grid2,"👨‍⚕️","অ্যাড ডাক্তার"){ addSimple("ডাক্তারের নাম","doctors") }
        addCard(grid2,"👤","অ্যাড কেয়ার অফ"){ addSimple("কেয়ার অফ নাম","careOf") }
        content.addView(grid2)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun grid(): GridLayout = GridLayout(this).apply {
        columnCount=2; rowCount=2; useDefaultMargins=true
    }

    private fun addCard(g: GridLayout, icon:String, label:String, action:()->Unit) {
        val b=Button(this).apply {
            text="$icon\n\n$label"; textSize=18f; setTextColor(navy)
            setBackgroundColor(Color.WHITE); setPadding(dp(6),dp(18),dp(6),dp(18))
            minHeight=dp(135); setOnClickListener{action()}
        }
        val p=GridLayout.LayoutParams().apply {
            width=0; height=dp(145); columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)
            setMargins(dp(5),dp(5),dp(5),dp(5))
        }
        g.addView(b,p)
    }

    private fun addSerial() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(10),dp(22),0)}
        val name=EditText(this).apply{hint="রোগীর নাম"}
        val care=EditText(this).apply{hint="কেয়ার অফ নাম"}
        val doctor=EditText(this).apply{hint="ডাক্তারের নাম"}
        box.addView(name,lp());box.addView(care,lp());box.addView(doctor,lp())
        AlertDialogBuilder("নতুন সিরিয়াল",box,"সেভ"){ 
            val data=hashMapOf("patientName" to name.text.toString(),"careOf" to care.text.toString(),
                "doctor" to doctor.text.toString(),"status" to "waiting",
                "createdAt" to System.currentTimeMillis())
            db.collection("serials").add(data).addOnSuccessListener {
                Toast.makeText(this,"সিরিয়াল যোগ হয়েছে",Toast.LENGTH_SHORT).show()
            }.addOnFailureListener { Toast.makeText(this,"সেভ করা যায়নি: ${it.message}",Toast.LENGTH_LONG).show() }
        }
    }

    private fun addSimple(hint:String, collection:String) {
        val e=EditText(this).apply{this.hint=hint}
        AlertDialogBuilder("নতুন $hint",e,"সেভ"){
            val v=e.text.toString().trim()
            if(v.isNotEmpty()) db.collection(collection).add(mapOf("name" to v, "createdAt" to System.currentTimeMillis()))
        }
    }

    private fun showList(status:String) {
        val tv=TextView(this).apply{setPadding(dp(20),dp(10),dp(20),dp(10));textSize=16f}
        val dlg=android.app.AlertDialog.Builder(this).setTitle("সিরিয়াল তালিকা").setView(tv).setPositiveButton("বন্ধ",null).create()
        dlg.show()
        var q=db.collection("serials")
        if(status!="all") q=q.whereEqualTo("status",status)
        q.orderBy("createdAt").limit(100).get().addOnSuccessListener { snap ->
            val s=StringBuilder()
            snap.documents.forEachIndexed{ i,d ->
                s.append("${i+1}. ${d.getString("patientName") ?: ""} | ${d.getString("doctor") ?: ""} | ${d.getString("status") ?: ""}\n")
            }
            tv.text=if(s.isEmpty()) "কোনো তথ্য নেই" else s.toString()
        }.addOnFailureListener{tv.text="ডেটা লোড করা যায়নি\n${it.message}"}
    }

    private fun AlertDialogBuilder(title:String, view:View, positive:String, action:()->Unit) {
        android.app.AlertDialog.Builder(this).setTitle(title).setView(view)
            .setNegativeButton("বাতিল",null).setPositiveButton(positive){_,_->action()}.show()
    }
    private fun lp()=LinearLayout.LayoutParams(-1,dp(55)).apply{bottomMargin=dp(5)}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
