# Moon Diagnostic Center v2

এই প্রজেক্টটি দেওয়া স্ক্রিনশটের UI অনুসরণ করে নতুন করে তৈরি করা হয়েছে—কার্ডগুলো আগের বড় ডিজাইনের তুলনায় সামান্য compact রাখা হয়েছে।

## গুরুত্বপূর্ণ
Firebase চালু করতে Firebase Console থেকে Android app যোগ করে `google-services.json` ফাইলটি `app/` ফোল্ডারে রাখতে হবে। এরপর Authentication/Firestore চালু করতে হবে।

## GitHub দিয়ে APK
1. পুরো ZIP GitHub repository-তে upload করুন।
2. `app/google-services.json` যোগ করুন (Firebase Console থেকে)।
3. Actions → Build Moon Diagnostic APK → Run workflow।
4. workflow শেষ হলে Artifacts থেকে APK নিন।

## বর্তমান UI/ফিচার
- Admin/User role header
- Logout
- আজকের পরিসংখ্যান: মোট, অপেক্ষমাণ, সম্পন্ন, বাতিল
- দ্রুত অ্যাকশন: টোটাল সিরিয়াল, অ্যাড সিরিয়াল, অ্যাড ডাক্তার, অ্যাড কেয়ার অফ
- Firestore serial/doctor/careOf storage
- Waiting/Completed/Cancelled status-ready data model
- Firestore index ও rules ফাইল
- GitHub Actions APK build workflow

## নিরাপত্তা
Production ব্যবহারের আগে Firestore rules-এ Admin/Operator/User custom claims বা users collection অনুযায়ী role-based authorization বসাতে হবে। শুধুমাত্র client-side role text দিয়ে security করা যাবে না।
