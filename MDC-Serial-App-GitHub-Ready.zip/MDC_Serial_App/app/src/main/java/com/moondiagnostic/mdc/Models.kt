
package com.moondiagnostic.mdc

data class Serial(
    val number:Int, val date:String, val patient:String,
    val careOf:String, val doctor:String, var status:String, val time:String
)
data class AppUser(val username:String, val passwordHash:String, val role:String)
