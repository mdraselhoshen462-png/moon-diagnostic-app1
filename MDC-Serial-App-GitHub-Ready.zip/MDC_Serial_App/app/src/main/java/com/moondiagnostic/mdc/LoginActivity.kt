
package com.moondiagnostic.mdc

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.content.Intent

class LoginActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);AppStore.init(this);show()}
 private fun show(){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,45,24,24);gravity=Gravity.CENTER_HORIZONTAL;setBackgroundColor(Color.rgb(242,248,252))}
  root.addView(Ui.tv(this,"MDC",58f,Color.rgb(30,93,145),false))
  root.addView(Ui.tv(this,"মুন ডায়াগনস্টিক সেন্টার",20f,Color.rgb(30,93,145),true))
  root.addView(Ui.tv(this,"নিরাপদ লগইন",18f,Color.DKGRAY,true))
  val u=EditText(this).apply{hint="Username";setSingleLine()}
  val p=EditText(this).apply{hint="Password";inputType=0x81;setSingleLine()}
  root.addView(Ui.margin(u));root.addView(Ui.margin(p))
  val role=Spinner(this);role.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Admin","Operator","User"));root.addView(Ui.margin(role))
  val btn=Ui.button(this,"🔐  Login");root.addView(Ui.margin(btn,8,16,8,8))
  root.addView(Ui.tv(this,"ডেমো Admin: admin / admin123",13f,Color.GRAY))
  btn.setOnClickListener{
   val user=AppStore.login(this,u.text.toString().trim(),p.text.toString())
   if(user==null) Toast.makeText(this,"Username বা Password ভুল",Toast.LENGTH_SHORT).show()
   else {getSharedPreferences("session",0).edit().putString("u",user.username).putString("r",user.role).apply();startActivity(Intent(this,MainActivity::class.java));finish()}
  }
  setContentView(root)
 }
}
