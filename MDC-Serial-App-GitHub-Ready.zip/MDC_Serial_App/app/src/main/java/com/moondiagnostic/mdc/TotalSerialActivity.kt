
package com.moondiagnostic.mdc

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*

class TotalSerialActivity:Activity(){
 private val navy=Color.rgb(23,74,115)
 override fun onCreate(b:Bundle?){super.onCreate(b);draw()}
 private fun draw(){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,8,10,15);setBackgroundColor(Color.rgb(242,248,252))}
  val sv=ScrollView(this);sv.addView(root);setContentView(sv)
  val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  val back=Ui.button(this,"‹",Color.TRANSPARENT);back.setTextColor(navy);top.addView(back,LinearLayout.LayoutParams(55,50));top.addView(Ui.tv(this,"টোটাল সিরিয়াল",20f,navy,true),LinearLayout.LayoutParams(0,50,1f));root.addView(top);back.setOnClickListener{finish()}
  val date=Spinner(this);date.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf(AppStore.today()));root.addView(Ui.margin(date,6,4,6,6))
  val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
  val all=Ui.button(this,"সব সিরিয়াল",navy);val doc=Ui.button(this,"ডাক্তার ওয়াইজ",Color.WHITE);val care=Ui.button(this,"কেয়ার অফ ওয়াইজ",Color.WHITE)
  doc.setTextColor(navy);care.setTextColor(navy);tabs.addView(all,LinearLayout.LayoutParams(0,50,1f));tabs.addView(doc,LinearLayout.LayoutParams(0,50,1f));tabs.addView(care,LinearLayout.LayoutParams(0,50,1f));root.addView(tabs)
  val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};root.addView(content)
  fun render(mode:Int){
   content.removeAllViews()
   if(mode==1){
    val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("ডাক্তার নির্বাচন করুন")+AppStore.doctors(this));content.addView(Ui.margin(sp));sp.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{
     override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){if(pos>0)showList(content,AppStore.serials(this@TotalSerialActivity).filter{it.doctor==sp.selectedItem.toString()})}
    });return
   }
   if(mode==2){
    val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("কেয়ার অফ নির্বাচন করুন")+AppStore.cares(this));content.addView(Ui.margin(sp));sp.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{
     override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){if(pos>0)showList(content,AppStore.serials(this@TotalSerialActivity).filter{it.careOf==sp.selectedItem.toString()})}
    });return
   }
   showList(content,AppStore.serials(this).filter{it.date==AppStore.today()})
  }
  fun setTab(selected:Button,others:List<Button>){selected.setTextColor(Color.WHITE);selected.background=android.graphics.drawable.GradientDrawable().apply{setColor(navy);cornerRadius=10f};others.forEach{it.setTextColor(navy);it.background=Ui.bg(this)}}
  all.setOnClickListener{setTab(all,listOf(doc,care));render(0)};doc.setOnClickListener{setTab(doc,listOf(all,care));render(1)};care.setOnClickListener{setTab(care,listOf(all,doc));render(2)}
  setTab(all,listOf(doc,care));render(0)
 }
 private fun showList(content:LinearLayout,list:List<Serial>){
  content.removeAllViews()
  if(list.isEmpty()){content.addView(Ui.tv(this,"কোনো সিরিয়াল পাওয়া যায়নি",16f,Color.GRAY,true));return}
  for(s in list){
   val c=Ui.card(this);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
   row.addView(Ui.tv(this,"# %02d".format(s.number),16f,Color.DKGRAY,true),LinearLayout.LayoutParams(0,40,1f))
   val col=when(s.status){"সম্পন্ন"->Color.rgb(25,135,84);"বাতিল"->Color.rgb(195,45,50);else->Color.rgb(239,145,20)}
   row.addView(Ui.tv(this,s.status,13f,col,true),LinearLayout.LayoutParams(110,40));c.addView(row)
   c.addView(Ui.tv(this,"রোগী: ${s.patient}",14f,Color.DKGRAY,false));c.addView(Ui.tv(this,"ডাক্তার: ${s.doctor}",13f,Color.DKGRAY,false));c.addView(Ui.tv(this,"কেয়ার: ${s.careOf}",13f,Color.DKGRAY,false));c.addView(Ui.tv(this,s.time,12f,Color.GRAY,false))
   c.setOnClickListener{showStatus(s)};content.addView(Ui.margin(c,4,5,4,5))
  }
 }
 private fun showStatus(s:Serial){
  val role=getSharedPreferences("session",0).getString("r","User")
  if(role=="User"){Toast.makeText(this,"User শুধু সিরিয়াল দেখতে পারবে",Toast.LENGTH_SHORT).show();return}
  AlertDialog.Builder(this).setTitle("সিরিয়াল #${s.number}").setItems(arrayOf("অপেক্ষমাণ","সম্পন্ন","বাতিল")){_,w->AppStore.setStatus(this,s.number,arrayOf("অপেক্ষমাণ","সম্পন্ন","বাতিল")[w]);draw()}.show()
 }
}
