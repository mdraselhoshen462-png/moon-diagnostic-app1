
package com.moondiagnostic.mdc

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*

class MainActivity:Activity(){
 private val navy=Color.rgb(23,74,115); private val blue=Color.rgb(31,99,151)
 override fun onCreate(b:Bundle?){super.onCreate(b);AppStore.init(this);draw()}
 override fun onResume(){super.onResume(); if(::root.isInitialized) draw()}
 private lateinit var root:LinearLayout
 private fun draw(){
  root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,8,12,18);setBackgroundColor(Color.rgb(242,248,252))}
  val sv=ScrollView(this);sv.addView(root);setContentView(sv)
  val sp=getSharedPreferences("session",0);val user=sp.getString("u","admin")?:"admin";val role=sp.getString("r","Admin")?:"Admin"
  root.addView(Ui.tv(this,"MDC",48f,Color.rgb(30,93,145)))
  root.addView(Ui.tv(this,"স্বাগতম, $user",21f,Color.DKGRAY,true))
  root.addView(Ui.tv(this,"Role: $role",16f,Color.rgb(35,137,125)))
  val logout=Ui.button(this,"🚪  Logout",Color.rgb(207,53,57));root.addView(Ui.margin(logout,0,5,0,8));logout.setOnClickListener{sp.edit().clear().apply();startActivity(Intent(this,LoginActivity::class.java));finish()}
  root.addView(Ui.tv(this,"আজকের তারিখ",24f,navy,true));root.addView(Ui.tv(this,AppStore.today(),17f,Color.DKGRAY))
  val today=AppStore.serials(this).filter{it.date==AppStore.today()}
  val grid=GridLayout(this).apply{columnCount=2;rowCount=2}
  fun stat(icon:String,label:String,count:Int,color:Int){
   val c=Ui.card(this);c.gravity=Gravity.CENTER;c.addView(Ui.tv(this,icon,32f));c.addView(Ui.tv(this,label,15f,navy,true));c.addView(Ui.tv(this,count.toString(),20f,color,true))
   grid.addView(c,GridLayout.LayoutParams().apply{width=0;height=92;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(3,4,3,4)})
  }
  stat("👥","মোট সিরিয়াল",today.size,navy);stat("⌛","অপেক্ষমাণ",today.count{it.status=="অপেক্ষমাণ"},Color.rgb(245,150,20));stat("✓","সম্পন্ন",today.count{it.status=="সম্পন্ন"},Color.rgb(25,135,84));stat("✕","বাতিল",today.count{it.status=="বাতিল"},Color.rgb(190,45,50))
  root.addView(grid)
  root.addView(Ui.tv(this,"দ্রুত অ্যাকশন",25f,navy,true))
  val q=GridLayout(this).apply{columnCount=2}
  fun qbtn(t:String,go:Class<*>,color:Int=blue){val v=Ui.button(this,t,color);q.addView(v,GridLayout.LayoutParams().apply{width=0;height=58;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(3,3,3,3)});v.setOnClickListener{startActivity(Intent(this,go))}}
  qbtn("📋  টোটাল সিরিয়াল",TotalSerialActivity::class.java);qbtn("＋  অ্যাড সিরিয়াল",AddSerialActivity::class.java)
  qbtn("👨‍⚕️  অ্যাড ডাক্তার",AdminActivity::class.java);qbtn("👤  অ্যাড কেয়ার অফ",AdminActivity::class.java)
  root.addView(q)
  if(role=="Admin"){root.addView(Ui.tv(this,"👑 Admin Control Panel",24f,Color.rgb(102,70,160),true));val a=Ui.button(this,"⚙  Admin Control Panel",Color.rgb(105,72,166));root.addView(Ui.margin(a,0,2,0,5));a.setOnClickListener{startActivity(Intent(this,AdminActivity::class.java))}}
  val notice=Ui.card(this);notice.addView(Ui.tv(this,"🔄  ডেটা প্রতি ২০ সেকেন্ড পর পর অটো রিলোড হচ্ছে",15f,Color.rgb(30,135,135),true));notice.addView(Ui.tv(this,"সর্বশেষ আপডেট: এখন",13f,Color.GRAY));root.addView(Ui.margin(notice,0,8,0,4))
  root.addView(Ui.tv(this,"মুন ডায়াগনস্টিক সেন্টার",17f,Color.GRAY,true));root.addView(Ui.tv(this,"আপনার বিশ্বস্ত স্বাস্থ্যসেবা কেন্দ্র",13f,Color.GRAY))
 }
}
