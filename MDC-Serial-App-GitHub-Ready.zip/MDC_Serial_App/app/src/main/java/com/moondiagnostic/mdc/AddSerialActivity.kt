
package com.moondiagnostic.mdc

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import android.content.Intent

class AddSerialActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);draw()}
 private fun draw(){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,12,14,20);setBackgroundColor(Color.rgb(242,248,252))}
  val sv=ScrollView(this);sv.addView(root);setContentView(sv)
  val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  val back=Ui.button(this,"‹",Color.TRANSPARENT);back.setTextColor(Color.rgb(23,74,115));top.addView(back,LinearLayout.LayoutParams(55,52));top.addView(Ui.tv(this,"অ্যাড সিরিয়াল",20f,Color.rgb(23,74,115),true),LinearLayout.LayoutParams(0,52,1f));root.addView(top);back.setOnClickListener{finish()}
  root.addView(Ui.tv(this,"তারিখ",14f,Color.DKGRAY,false))
  val date=EditText(this).apply{setText(AppStore.today());isEnabled=false};root.addView(Ui.margin(date))
  val patient=EditText(this).apply{hint="রোগীর নাম লিখুন";setSingleLine()};root.addView(Ui.tv(this,"রোগীর নাম",14f,Color.DKGRAY));root.addView(Ui.margin(patient))
  val care=Spinner(this);care.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("কেয়ার অফ নির্বাচন করুন")+AppStore.cares(this));root.addView(Ui.tv(this,"কেয়ার অফ",14f,Color.DKGRAY));root.addView(Ui.margin(care))
  val doctor=Spinner(this);doctor.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("ডাক্তার নির্বাচন করুন")+AppStore.doctors(this));root.addView(Ui.tv(this,"ডাক্তার",14f,Color.DKGRAY));root.addView(Ui.margin(doctor))
  val save=Ui.button(this,"✓  সিরিয়াল তৈরি করুন");root.addView(Ui.margin(save,8,14,8,5))
  val cancel=Ui.button(this,"বাতিল করুন",Color.WHITE);cancel.setTextColor(Color.rgb(23,74,115));cancel.background=Ui.bg(this);root.addView(Ui.margin(cancel))
  save.setOnClickListener{
   if(patient.text.toString().trim().isEmpty()||care.selectedItemPosition==0||doctor.selectedItemPosition==0){Toast.makeText(this,"সব তথ্য নির্বাচন করুন",Toast.LENGTH_SHORT).show();return@setOnClickListener}
   val s=AppStore.addSerial(this,patient.text.toString().trim(),care.selectedItem.toString(),doctor.selectedItem.toString())
   Toast.makeText(this,"সিরিয়াল #${s.number} তৈরি হয়েছে",Toast.LENGTH_LONG).show()
   startActivity(Intent(this,TotalSerialActivity::class.java));finish()
  }
  cancel.setOnClickListener{finish()}
 }
}
