
package com.moondiagnostic.mdc

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context

object Ui {
    fun bg(c:Context)=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=14f;setStroke(1,Color.rgb(215,227,234))}
    fun button(c:Context,text:String,color:Int=Color.rgb(23,98,154)):Button=Button(c).apply{
        this.text=text; setTextColor(Color.WHITE); textSize=15f; isAllCaps=false
        background=GradientDrawable().apply{setColor(color);cornerRadius=12f}
        minHeight=48
    }
    fun card(c:Context):LinearLayout=LinearLayout(c).apply{
        orientation=LinearLayout.VERTICAL;setPadding(14,12,14,12);background=bg(c)
    }
    fun tv(c:Context,text:String,size:Float=16f,color:Int=Color.rgb(23,74,115),bold:Boolean=false)=TextView(c).apply{
        this.text=text;textSize=size;setTextColor(color);gravity=Gravity.CENTER
        if(bold) setTypeface(typeface,android.graphics.Typeface.BOLD)
        setPadding(4,4,4,4)
    }
    fun margin(v:View,l:Int=8,t:Int=6,r:Int=8,b:Int=6)=v.apply{
        layoutParams=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT).apply{
            setMargins(l,t,r,b)
        }
    }
}
