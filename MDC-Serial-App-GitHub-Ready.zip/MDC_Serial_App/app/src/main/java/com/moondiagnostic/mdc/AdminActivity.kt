
package com.moondiagnostic.mdc

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class AdminActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);draw()}
 private fun draw(){
  val role=getSharedPreferences("session",0).getString("r","User")
  if(role!="Admin"){Toast.makeText(this,"শুধু Admin এই পেজ ব্যবহার করতে পারবে",Toast.LENGTH_LONG).show();finish();return}
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,12,14,20);setBackgroundColor(Color.rgb(242,248,252))}
  val sv=ScrollView(this);sv.addView(root);setContentView(sv)
  val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  val back=Ui.button(this,"‹",Color.TRANSPARENT);back.setTextColor(Color.rgb(23,74,115));top.addView(back,LinearLayout.LayoutParams(55,50));top.addView(Ui.tv(this,"Admin Control Panel",20f,Color.rgb(23,74,115),true));root.addView(top);back.setOnClickListener{finish()}
  root.addView(Ui.tv(this,"নতুন User / Operator তৈরি করুন",20f,Color.rgb(23,74,115),true))
  val u=EditText(this).apply{hint="Username";setSingleLine()};val p=EditText(this).apply{hint="Password";inputType=0x81;setSingleLine()}
  val r=Spinner(this);r.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("User","Operator"))
  root.addView(Ui.margin(u));root.addView(Ui.margin(p));root.addView(Ui.margin(r))
  val add=Ui.button(this,"＋  User / Operator তৈরি করুন",Color.rgb(105,72,166));root.addView(Ui.margin(add))
  add.setOnClickListener{if(AppStore.addUser(this,u.text.toString().trim(),p.text.toString(),r.selectedItem.toString())){Toast.makeText(this,"User তৈরি হয়েছে",Toast.LENGTH_SHORT).show();u.text.clear();p.text.clear();draw()}else Toast.makeText(this,"Username ফাঁকা/আগে থেকেই আছে",Toast.LENGTH_SHORT).show()}
  root.addView(Ui.tv(this,"বর্তমান User / Operator",18f,Color.rgb(23,74,115),true))
  AppStore.users(this).filter{it.username!="admin"}.forEach{usr->
   val c=Ui.card(this);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
   row.addView(Ui.tv(this,"${usr.username}\nRole: ${usr.role}",14f,Color.DKGRAY,false),LinearLayout.LayoutParams(0,60,1f))
   val del=Ui.button(this,"🗑",Color.TRANSPARENT);del.setTextColor(Color.rgb(190,45,50));row.addView(del,LinearLayout.LayoutParams(60,55));c.addView(row);root.addView(Ui.margin(c))
   del.setOnClickListener{AppStore.deleteUser(this,usr.username);draw()}
  }
  root.addView(Ui.tv(this,"ডাক্তার / কেয়ার অফ",18f,Color.rgb(23,74,115),true))
  val d=EditText(this).apply{hint="নতুন ডাক্তার নাম"};val db=Ui.button(this,"＋ ডাক্তার যোগ",Color.rgb(31,99,151));root.addView(Ui.margin(d));root.addView(Ui.margin(db));db.setOnClickListener{AppStore.addDoctor(this,d.text.toString());d.text.clear();Toast.makeText(this,"ডাক্তার যোগ হয়েছে",Toast.LENGTH_SHORT).show()}
  val c=EditText(this).apply{hint="নতুন কেয়ার অফ নাম"};val cb=Ui.button(this,"＋ কেয়ার অফ যোগ",Color.rgb(31,99,151));root.addView(Ui.margin(c));root.addView(Ui.margin(cb));cb.setOnClickListener{AppStore.addCare(this,c.text.toString());c.text.clear();Toast.makeText(this,"কেয়ার অফ যোগ হয়েছে",Toast.LENGTH_SHORT).show()}
 }
}
