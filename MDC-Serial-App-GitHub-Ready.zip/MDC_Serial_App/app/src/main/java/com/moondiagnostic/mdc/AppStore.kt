
package com.moondiagnostic.mdc

import android.content.Context
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import org.json.JSONArray
import org.json.JSONObject

object AppStore {
    private const val PREF = "mdc_store"
    private const val USERS = "users"
    private const val SERIALS = "serials"
    private const val DOCTORS = "doctors"
    private const val CARES = "cares"

    private fun prefs(c:Context)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE)

    fun hash(s:String):String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
        .joinToString(""){"%02x".format(it)}

    fun init(c:Context) {
        val p=prefs(c)
        if(!p.contains(USERS)){
            val a=JSONArray().put(JSONObject().apply{
                put("u","admin"); put("p",hash("admin123")); put("r","Admin")
            })
            p.edit().putString(USERS,a.toString()).apply()
        }
        if(!p.contains(DOCTORS)) p.edit().putString(DOCTORS,JSONArray()
            .put("ডাঃ নাসির উদ্দিন").put("ডাঃ তানভীর আহমেদ").put("ডাঃ শফিউল কাদির").toString()).apply()
        if(!p.contains(CARES)) p.edit().putString(CARES,JSONArray()
            .put("সকাল আহমেদ").put("আফিফ হোসেন").put("আলিফা রহমান").toString()).apply()
        if(!p.contains(SERIALS)) p.edit().putString(SERIALS,JSONArray().toString()).apply()
    }

    fun login(c:Context,u:String,pw:String):AppUser?{
        val a=JSONArray(prefs(c).getString(USERS,"[]"))
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i)
            if(o.getString("u")==u && o.getString("p")==hash(pw))
                return AppUser(u,o.getString("p"),o.getString("r"))
        }
        return null
    }

    fun users(c:Context):List<AppUser>{
        val a=JSONArray(prefs(c).getString(USERS,"[]"))
        return (0 until a.length()).map{ val o=a.getJSONObject(it); AppUser(o.getString("u"),o.getString("p"),o.getString("r")) }
    }

    fun addUser(c:Context,u:String,pw:String,r:String):Boolean{
        if(u.isBlank()||pw.isBlank()) return false
        val a=JSONArray(prefs(c).getString(USERS,"[]"))
        if((0 until a.length()).any{a.getJSONObject(it).getString("u").equals(u,true)}) return false
        a.put(JSONObject().apply{put("u",u);put("p",hash(pw));put("r",r)})
        prefs(c).edit().putString(USERS,a.toString()).apply(); return true
    }

    fun deleteUser(c:Context,u:String){
        val a=JSONArray(prefs(c).getString(USERS,"[]")); val b=JSONArray()
        for(i in 0 until a.length()) if(a.getJSONObject(i).getString("u")!=u) b.put(a.getJSONObject(i))
        prefs(c).edit().putString(USERS,b.toString()).apply()
    }

    fun doctors(c:Context)=strings(c,DOCTORS)
    fun cares(c:Context)=strings(c,CARES)
    private fun strings(c:Context,k:String):List<String>{
        val a=JSONArray(prefs(c).getString(k,"[]")); return (0 until a.length()).map{a.getString(it)}
    }

    fun addDoctor(c:Context,s:String){ addString(c,DOCTORS,s) }
    fun addCare(c:Context,s:String){ addString(c,CARES,s) }
    private fun addString(c:Context,k:String,s:String){
        if(s.isBlank())return
        val a=JSONArray(prefs(c).getString(k,"[]")); if((0 until a.length()).any{a.getString(it)==s})return
        a.put(s);prefs(c).edit().putString(k,a.toString()).apply()
    }

    @Synchronized fun addSerial(c:Context,patient:String,care:String,doctor:String):Serial{
        val list=serials(c).filter{it.date==today()}
        val n=(list.maxOfOrNull{it.number}?:0)+1
        val t=SimpleDateFormat("hh:mm a",Locale.US).format(Date())
        val s=Serial(n,today(),patient,care,doctor,"অপেক্ষমাণ",t)
        val a=JSONArray(prefs(c).getString(SERIALS,"[]"))
        a.put(JSONObject().apply{
            put("n",s.number);put("d",s.date);put("p",s.patient);put("c",s.careOf);put("dr",s.doctor);put("st",s.status);put("t",s.time)
        })
        prefs(c).edit().putString(SERIALS,a.toString()).apply(); return s
    }

    fun serials(c:Context):List<Serial>{
        val a=JSONArray(prefs(c).getString(SERIALS,"[]"))
        return (0 until a.length()).map{
            val o=a.getJSONObject(it)
            Serial(o.getInt("n"),o.getString("d"),o.getString("p"),o.getString("c"),o.getString("dr"),o.getString("st"),o.getString("t"))
        }.sortedBy{it.number}
    }

    fun setStatus(c:Context,n:Int,status:String,date:String=today()){
        val a=JSONArray(prefs(c).getString(SERIALS,"[]"))
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i)
            if(o.getInt("n")==n && o.getString("d")==date){o.put("st",status)}
        }
        prefs(c).edit().putString(SERIALS,a.toString()).apply()
    }

    fun today()=SimpleDateFormat("dd-MM-yyyy",Locale.US).format(Date())
}
