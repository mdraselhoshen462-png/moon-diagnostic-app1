# Production multi-device backend

The included build is intentionally standalone so GitHub can build it without private Firebase credentials.

For the production 20–25 device version:
1. Create a Firebase project.
2. Enable Firebase Authentication.
3. Enable Cloud Firestore.
4. Register the Android package: `com.moondiagnostic.mdc`.
5. Download `google-services.json` into `app/`.
6. Add the Firebase Android SDK and Google Services Gradle plugin.
7. Store `users`, `doctors`, `careOfs`, and `serials` in Firestore.
8. Allocate serial numbers inside a Firestore transaction keyed by date.
9. Add Security Rules so Admin/Operator/User have separate permissions.
10. Use snapshot listeners for real-time updates.

Do not commit private service-account keys. `google-services.json` is normally okay for Android Firebase configuration, but Firestore Security Rules must be configured correctly.
