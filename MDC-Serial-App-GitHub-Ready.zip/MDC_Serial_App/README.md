# MDC Serial App — GitHub-ready Android project

এই প্রজেক্টটি আপনার দেওয়া 6-screen reference layout অনুসারে নতুন করে বানানো হয়েছে:

1. Login
2. Main Dashboard
3. Total Serial — সব/ডাক্তার ওয়াইজ/কেয়ার অফ ওয়াইজ ট্যাব
4. Add Serial
5. Doctor Wise Serial
6. Care Of Wise Serial
7. Admin Control Panel

## বর্তমান build
- Native Kotlin Android
- Responsive card/grid layout
- Admin / Operator / User role
- Local persistent demo data
- Serial status: অপেক্ষমাণ / সম্পন্ন / বাতিল
- Doctor ও Care Of filter
- Admin থেকে user/operator তৈরি ও মুছা
- GitHub Actions দিয়ে Debug APK build

### Demo login
- Username: `admin`
- Password: `admin123`
- Role: Admin

> গুরুত্বপূর্ণ: এই সংস্করণটি সরাসরি build ও UI/feature testing-এর জন্য standalone। 20–25টি ফোনে একই data live sync, server-side authentication এবং duplicate serial prevention-এর জন্য Firebase/Firestore backend connect করতে হবে। এই ZIP-এ সেই integration-এর জায়গা পরিষ্কার রাখা হয়েছে; তাই `google-services.json` না থাকলেও build ভাঙবে না।

## GitHub-এ নতুন Repository
1. GitHub → New repository
2. নাম দিন `MDC-Serial-App`
3. এই ZIP extract করে সব ফাইল repository root-এ upload করুন।
4. `.github/workflows/build-apk.yml` থাকবে।
5. Actions → Build APK → Run workflow.
6. Build শেষ হলে Artifacts থেকে `MDC-debug-apk` download করুন।

## ভবিষ্যৎ Firebase production setup
- Firebase Authentication
- Firestore collections: users, doctors, careOfs, serials
- Transaction-based serial number allocation
- Firestore Security Rules: Admin/Operator/User
- Real-time listeners
- Audit log

এই অংশটি backend credentials ছাড়া নিরাপদভাবে সম্পূর্ণ করা যায় না; `google-services.json` এবং Firebase project প্রয়োজন।
