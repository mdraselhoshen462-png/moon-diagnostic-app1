# Reference-matching checklist

- [x] MDC header
- [x] স্বাগতম + Role
- [x] Red Logout bar
- [x] আজকের তারিখ
- [x] 2×2 statistic cards
- [x] 2×2 quick-action cards
- [x] Doctor-wise/Care-of-wise are NOT shown separately on dashboard
- [x] Total Serial contains 3 tabs: সব সিরিয়াল / ডাক্তার ওয়াইজ / কেয়ার অফ ওয়াইজ
- [x] Add Serial screen with date, patient, care-of, doctor
- [x] Status: অপেক্ষমাণ / সম্পন্ন / বাতিল
- [x] Admin Control Panel
- [x] Admin can create/delete User and Operator
- [x] Doctor and Care Of master lists
- [x] GitHub Actions debug APK build
