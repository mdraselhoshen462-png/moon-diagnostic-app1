# Moon Diagnostic Center (MDC) — GitHub APK Project

## এই ভার্সনের UI
আপনার দেওয়া সর্বশেষ reference image অনুসারে:
- MDC header + Welcome + Role
- Logout
- আজকের তারিখ
- 2×2 statistics cards
- দ্রুত অ্যাকশন 2×2: Total Serial, Add Serial, Add Doctor, Add Care Of
- Doctor-wise / Care-wise আলাদা dashboard section বাদ
- Total Serial-এর ভিতরে: সব সিরিয়াল / ডাক্তার ওয়াইজ / কেয়ার ওয়াইজ filter
- Admin Control Panel
- 20-second refresh information
- Firebase Auth + Firestore-ready structure
- Admin / Operator / User role model
- GitHub Actions দিয়ে APK build

## GitHub-এ বসানোর ধাপ
1. GitHub-এ নতুন repository তৈরি করুন।
2. এই ZIP-এর সব ফাইল repository root-এ upload/extract করুন।
3. Commit করুন।
4. Actions → Build Moon Diagnostic APK → Run workflow চাপুন।
5. Build শেষ হলে Artifacts থেকে `Moon-Diagnostic-Debug-APK` download করুন।

## Firebase সংযোগ
Firebase Console-এ Android app package name দিন:
`com.moondiagnostic.app`

তারপর Firebase Authentication → Email/Password enable করুন এবং Firestore Database তৈরি করুন।

Google Services config ব্যবহার করতে চাইলে Firebase-এর `google-services.json` ফাইলটি `app/google-services.json`-এ দিন এবং Google Services Gradle plugin যোগ করুন।

বর্তমান source Firebase Auth/Firestore API ব্যবহার করে; Firebase config না দিলে runtime-এ cloud login/data কাজ করবে না।

## নিরাপদ Admin/User/Operator
- Admin-ই User/Operator তৈরি করবে।
- User/Operator-এর role Firestore `users` collection-এ থাকবে।
- Admin account তৈরি করতে Firebase Console দিয়ে প্রথম admin user বানিয়ে তার Firestore profile-এ role=`Admin` দিন।
- এরপর Admin Control Panel থেকে Cloud Function `createUser` ব্যবহার করে User/Operator তৈরি করুন।
- `firestore.rules`-এ Admin-only management rule দেওয়া আছে।

## Serial structure
`serials` collection:
- patient
- doctor
- care
- status: WAITING / COMPLETED / CANCELLED
- createdAt

Production-এ একই দিনে duplicate serial আটকাতে Firestore transaction/counter document যোগ করা উচিত। এই project-এর UI ও base data layer প্রস্তুত আছে।

## গুরুত্বপূর্ণ
এটি GitHub build-ready project। Firebase project-এর নিজস্ব `google-services.json`, Firebase Auth, Firestore এবং প্রথম Admin account আপনার Firebase project অনুযায়ী সেট করতে হবে।
