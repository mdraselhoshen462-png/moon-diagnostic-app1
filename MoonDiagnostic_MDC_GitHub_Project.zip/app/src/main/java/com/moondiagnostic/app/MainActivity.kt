package com.moondiagnostic.app

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.*
import android.widget.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.*

data class SerialItem(
    val id: String = "",
    val number: Long = 0,
    val patient: String = "",
    val doctor: String = "",
    val care: String = "",
    val status: String = "WAITING",
    val time: String = ""
)

class MainActivity : Activity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val root by lazy { LinearLayout(this) }
    private var role = "Admin"
    private var username = "admin"

    private val blue = Color.rgb(33,100,155)
    private val bg = Color.rgb(243,248,252)
    private val text = Color.rgb(21,59,93)
    private val purple = Color.rgb(99,54,167)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun base(): LinearLayout {
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.setPadding(12, 10, 12, 10)
        return root
    }

    private fun tv(s:String, size:Float, bold:Boolean=false): TextView {
        val t=TextView(this)
        t.text=s; t.textSize=size; t.setTextColor(text)
        t.gravity=Gravity.CENTER
        if(bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        t.setPadding(6,4,6,4)
        return t
    }

    private fun btn(s:String, color:Int=blue, on:()->Unit): Button {
        val b=Button(this); b.text=s; b.setTextColor(Color.WHITE)
        b.setBackgroundColor(color); b.setOnClickListener{on()}
        b.isAllCaps=false
        b.layoutParams=LinearLayout.LayoutParams(-1,48).apply{setMargins(0,3,0,3)}
        return b
    }

    private fun showLogin() {
        base().removeAllViews()
        root.addView(tv("MDC",58,true))
        root.addView(tv("Moon Diagnostic Center",18))
        root.addView(tv("লগইন",27,true))
        val user=EditText(this); user.hint="Username"; root.addView(user)
        val pass=EditText(this); pass.hint="Password"; pass.inputType=129; root.addView(pass)
        root.addView(btn("Login",blue){
            val u=user.text.toString().trim(); val p=pass.text.toString()
            if(u.isBlank()||p.isBlank()){toast("Username ও Password দিন");return@btn}
            // Firebase Auth uses an email internally. Username mapping is kept in users/{username}.
            db.collection("users").document(u).get().addOnSuccessListener { d ->
                val email=d.getString("email") ?: "$u@moon-diagnostic.local"
                auth.signInWithEmailAndPassword(email,p).addOnSuccessListener {
                    role=d.getString("role") ?: "User"; username=u; showDashboard()
                }.addOnFailureListener { toast("Login failed: ${it.message}") }
            }.addOnFailureListener { toast("User পাওয়া যায়নি") }
        })
        root.addView(tv("Admin ছাড়া User/Operator ব্যবহার করতে পারবে না।",14))
        setContentView(root)
    }

    private fun showDashboard() {
        base().removeAllViews()
        root.addView(tv("MDC",54,true))
        root.addView(tv("স্বাগতম, $username",25,true))
        root.addView(tv("Role: $role",17))
        root.addView(btn("🚪  Logout", Color.rgb(211,58,58)){auth.signOut();showLogin()})
        root.addView(tv("আজকের তারিখ",25,true))
        root.addView(tv(SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(Date()),19))

        val grid=GridLayout(this); grid.columnCount=2
        val stats=listOf("👥\nমোট সিরিয়াল\n32","⌛\nঅপেক্ষমাণ\n18","✓\nসম্পন্ন\n12","✕\nবাতিল\n2")
        stats.forEachIndexed{ i,s ->
            val b=Button(this); b.text=s; b.textSize=15f; b.setTextColor(text); b.isAllCaps=false
            grid.addView(b,GridLayout.LayoutParams().apply{width=0;height=82;columnSpec=GridLayout.spec(i%2,1f);rowSpec=GridLayout.spec(i/2,1f);setMargins(3,3,3,3)})
        }
        root.addView(grid)
        root.addView(tv("দ্রুত অ্যাকশন",27,true))
        val actions=GridLayout(this); actions.columnCount=2
        val list=listOf("📋\nটোটাল সিরিয়াল","＋\nঅ্যাড সিরিয়াল","👨‍⚕️\nঅ্যাড ডাক্তার","👤\nঅ্যাড কেয়ার অফ")
        list.forEachIndexed{i,s->
            val b=Button(this);b.text=s;b.textSize=14f;b.isAllCaps=false;b.setTextColor(text)
            b.setOnClickListener{when(i){0->showTotal();1->showAddSerial();2->showSimpleAdd("ডাক্তার");3->showSimpleAdd("কেয়ার অফ")}}
            actions.addView(b,GridLayout.LayoutParams().apply{width=0;height=76;columnSpec=GridLayout.spec(i%2,1f);rowSpec=GridLayout.spec(i/2,1f);setMargins(3,3,3,3)})
        }
        root.addView(actions)
        root.addView(tv("Admin Control Panel",25,true))
        root.addView(tv("User এবং Operator পরিচালনা করুন",14))
        if(role.equals("Admin",true)) root.addView(btn("⚙  Admin Control Panel",purple){showAdmin()})
        root.addView(tv("🔄  ডাটা প্রতি ২০ সেকেন্ড পর পর অটো রিলোড হবে",14))
        root.addView(tv("মুন ডায়াগনস্টিক সেন্টার\nআপনার বিশ্বস্ত স্বাস্থ্যসেবা কেন্দ্র",16))
        setContentView(root)
    }

    private fun showTotal() {
        base().removeAllViews()
        root.addView(btn("←  টোটাল সিরিয়াল",blue){showDashboard()})
        root.addView(tv("টোটাল সিরিয়াল",28,true))
        root.addView(tv("তারিখ নির্বাচন করুন",15))
        val date=EditText(this); date.setText(SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(Date())); root.addView(date)
        val tabs=LinearLayout(this); tabs.orientation=LinearLayout.HORIZONTAL
        val all=btn("সব সিরিয়াল",blue){}; val doc=btn("ডাক্তার ওয়াইজ",blue){}; val care=btn("কেয়ার ওয়াইজ",blue){}
        tabs.addView(all,LinearLayout.LayoutParams(0,50,1f));tabs.addView(doc,LinearLayout.LayoutParams(0,50,1f));tabs.addView(care,LinearLayout.LayoutParams(0,50,1f))
        root.addView(tabs)
        root.addView(tv("ডাক্তার নির্বাচন করলে শুধু ওই ডাক্তারের সিরিয়াল দেখা যাবে।",13))
        root.addView(tv("কেয়ার অফ নির্বাচন করলে শুধু ওই কেয়ার অফ-এর সিরিয়াল দেখা যাবে।",13))
        val doctor=Spinner(this); doctor.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("ডাক্তার নির্বাচন করুন","ডাঃ নাসির উদ্দিন","ডাঃ তানভীর আহমেদ"));root.addView(doctor)
        val care=Spinner(this); care.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("কেয়ার অফ নির্বাচন করুন","সকল আহমেদ","আফ্রিক হোসেন"));root.addView(care)
        root.addView(btn("ফিল্টার দেখুন",blue){toast("Filter প্রয়োগ হয়েছে")})
        for(i in 1..4) root.addView(serialCard(i))
        setContentView(root)
    }

    private fun serialCard(n:Int):View {
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(14,8,14,8)
        box.setBackgroundColor(Color.WHITE)
        box.addView(tv("# $n                         অপেক্ষমাণ",18,true))
        box.addView(tv("রোগী: নমুনা রোগী $n",15,false))
        box.addView(tv("ডাক্তার: ডাঃ নাসির উদ্দিন",14,false))
        box.addView(tv("কেয়ার: সকল আহমেদ          09:${10+n} AM",14,false))
        return box
    }

    private fun showAddSerial() {
        base().removeAllViews()
        root.addView(btn("←  অ্যাড সিরিয়াল",blue){showDashboard()})
        root.addView(tv("অ্যাড সিরিয়াল",28,true))
        val patient=EditText(this);patient.hint="রোগীর নাম";root.addView(patient)
        val care=Spinner(this);care.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("কেয়ার অফ নির্বাচন করুন","সকল আহমেদ","আফ্রিক হোসেন"));root.addView(care)
        val doctor=Spinner(this);doctor.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("ডাক্তার নির্বাচন করুন","ডাঃ নাসির উদ্দিন","ডাঃ তানভীর আহমেদ"));root.addView(doctor)
        root.addView(btn("✓  সিরিয়াল তৈরি করুন",blue){
            if(patient.text.toString().isBlank()){toast("রোগীর নাম দিন");return@btn}
            val data=hashMapOf("patient" to patient.text.toString(),"doctor" to doctor.selectedItem.toString(),"care" to care.selectedItem.toString(),"status" to "WAITING","createdAt" to System.currentTimeMillis())
            db.collection("serials").add(data).addOnSuccessListener{toast("সিরিয়াল তৈরি হয়েছে");showTotal()}.addOnFailureListener{toast("ডাটা সংরক্ষণ হয়নি: ${it.message}")}
        })
        root.addView(btn("বাতিল করুন",Color.WHITE){showDashboard()}.apply{setTextColor(blue)})
        setContentView(root)
    }

    private fun showSimpleAdd(kind:String){
        base().removeAllViews();root.addView(btn("←  $kind যোগ করুন",blue){showDashboard()})
        root.addView(tv("$kind যোগ করুন",28,true))
        val e=EditText(this);e.hint="$kind-এর নাম";root.addView(e)
        root.addView(btn("＋ সংরক্ষণ করুন",blue){if(e.text.isNotBlank())toast("$kind সংরক্ষণ হয়েছে");showDashboard()})
        setContentView(root)
    }

    private fun showAdmin(){
        base().removeAllViews();root.addView(btn("←  Admin Control Panel",purple){showDashboard()})
        root.addView(tv("👑 Admin Control Panel",27,true))
        root.addView(tv("শুধু Admin User এবং Operator পরিচালনা করতে পারবে।",14))
        val u=EditText(this);u.hint="নতুন Username";root.addView(u)
        val p=EditText(this);p.hint="নতুন Password";p.inputType=129;root.addView(p)
        val r=Spinner(this);r.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Operator","User"));root.addView(r)
        root.addView(btn("＋ User / Operator তৈরি করুন",purple){
            toast("এই ধাপে Firebase Cloud Function যুক্ত করে নিরাপদভাবে account তৈরি করুন।")
        })
        root.addView(tv("বর্তমান User / Operator",20,true))
        root.addView(tv("operator1  •  Operator\nuser1  •  User\nuser2  •  User",15))
        setContentView(root)
    }

    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
}
