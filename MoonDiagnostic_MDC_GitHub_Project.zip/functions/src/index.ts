import {onCall, HttpsError} from "firebase-functions/v2/https";
import {getAuth} from "firebase-admin/auth";
import {getFirestore, FieldValue} from "firebase-admin/firestore";
import {initializeApp} from "firebase-admin/app";

initializeApp();

export const createUser = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Login required");
  const db = getFirestore();
  const caller = await db.collection("users").doc(request.auth.uid).get();
  if (!caller.exists || caller.data()?.role !== "Admin")
    throw new HttpsError("permission-denied", "Admin only");

  const {username, password, role} = request.data;
  if (!username || !password || !["User","Operator"].includes(role))
    throw new HttpsError("invalid-argument", "Invalid user data");

  const email = `${username}@moon-diagnostic.local`;
  const user = await getAuth().createUser({email, password, displayName: username});
  await db.collection("users").doc(user.uid).set({
    username, email, role, createdAt: FieldValue.serverTimestamp()
  });
  return {uid: user.uid, username, role};
});
