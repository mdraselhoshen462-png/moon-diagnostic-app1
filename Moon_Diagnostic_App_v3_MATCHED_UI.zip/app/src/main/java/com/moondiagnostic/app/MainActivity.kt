package com.moondiagnostic.app

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val navy = Color.rgb(24, 65, 98)
    private val blue = Color.rgb(37, 99, 153)
    private val purple = Color.rgb(108, 76, 168)
    private val bg = Color.rgb(241, 248, 253)
    private val border = Color.rgb(205, 220, 230)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun showLogin() {
        val root = base()
        val logo = tv("MDC", 62f, Color.rgb(37,96,150), true).apply { gravity = Gravity.CENTER }
        root.addView(logo, lp(1f, 100))
        root.addView(tv("ইউজার লগইন", 26f, navy, true).apply { gravity=Gravity.CENTER }, lp())
        val user = EditText(this).apply { hint="ইউজারনেম"; setSingleLine() }
        val pass = EditText(this).apply { hint="পাসওয়ার্ড"; setSingleLine(); inputType=0x81 }
        root.addView(user, lp()); root.addView(pass, lp())
        val b = Button(this).apply { text="লগইন"; setTextColor(Color.WHITE); setBackgroundColor(blue) }
        root.addView(b, lp(0f, 52))
        b.setOnClickListener {
            if (user.text.isNullOrBlank() || pass.text.isNullOrBlank()) {
                toast("ইউজারনেম ও পাসওয়ার্ড দিন")
            } else showDashboard(user.text.toString().trim())
        }
        setContentView(root)
    }

    private fun showDashboard(username: String) {
        val scroll = ScrollView(this)
        val root = base()
        root.setPadding(dp(8), dp(4), dp(8), dp(16))

        root.addView(tv("MDC", 55f, Color.rgb(37,96,150), true).apply {
            gravity=Gravity.CENTER
        }, lp(1f, 86))
        root.addView(tv("স্বাগতম, $username", 25f, Color.DKGRAY, true).apply {
            gravity=Gravity.CENTER
        }, lp(1f, 45))
        root.addView(tv("Role: Admin", 20f, Color.rgb(42,145,135), false).apply {
            gravity=Gravity.CENTER
        }, lp(1f, 36))

        val logout = Button(this).apply {
            text="↪  Logout"; textSize=18f; setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(205,55,57))
        }
        root.addView(logout, lp(1f, 45))
        logout.setOnClickListener { showLogin() }

        root.addView(tv("আজকের তারিখ", 28f, navy, true).apply {
            gravity=Gravity.CENTER; setPadding(0,dp(12),0,0)
        }, lp(1f, 48))
        root.addView(tv(SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date()), 23f, Color.DKGRAY, false).apply {
            gravity=Gravity.CENTER
        }, lp(1f, 38))

        val stats = GridLayout(this).apply { columnCount=2; rowCount=2 }
        addStat(stats, "👥", "মোট সিরিয়াল", "0", "all")
        addStat(stats, "⌛", "অপেক্ষমাণ", "0", "waiting")
        addStat(stats, "✓", "সম্পন্ন", "0", "completed")
        addStat(stats, "✕", "বাতিল", "0", "cancelled")
        root.addView(stats, lp(1f, 122))

        root.addView(tv("দ্রুত অ্যাকশন", 28f, navy, true).apply {
            gravity=Gravity.CENTER; setPadding(0,dp(12),0,dp(4))
        }, lp(1f, 48))

        action(root,"📋   টোটাল সিরিয়াল"){ showList("all") }
        action(root,"＋   অ্যাড সিরিয়াল"){ addSerial() }
        action(root,"👨‍⚕️   অ্যাড ডাক্তার"){ addSimple("ডাক্তার","doctors") }
        action(root,"👤   অ্যাড কেয়ার অফ"){ addSimple("কেয়ার অফ","careOf") }

        root.addView(tv("ডাক্তার ওয়াইজ সিরিয়াল", 28f, navy, true).apply { gravity=Gravity.CENTER }, lp(1f, 46))
        root.addView(tv("ডাক্তার নির্বাচন করে তার সিরিয়ালগুলো দেখা যাবে", 17f, Color.GRAY).apply { gravity=Gravity.CENTER }, lp(1f, 34))
        val doctorButton = Button(this).apply {
            text="ডাক্তার নির্বাচন"; setTextColor(Color.WHITE); setBackgroundColor(blue)
        }
        root.addView(doctorButton, lp(1f, 44))
        doctorButton.setOnClickListener { chooseAndList("doctors") }

        root.addView(tv("কেয়ার ওয়াইজ সিরিয়াল", 28f, navy, true).apply { gravity=Gravity.CENTER }, lp(1f, 46))
        root.addView(tv("কেয়ার অফ নির্বাচন করে সংশ্লিষ্ট সিরিয়ালগুলো দেখা যাবে", 17f, Color.GRAY).apply { gravity=Gravity.CENTER }, lp(1f, 34))
        val careButton = Button(this).apply {
            text="কেয়ার অফ নির্বাচন"; setTextColor(Color.WHITE); setBackgroundColor(blue)
        }
        root.addView(careButton, lp(1f, 44))
        careButton.setOnClickListener { chooseAndList("careOf") }

        root.addView(tv("👑 Admin Control Panel", 27f, Color.rgb(101,75,165), true).apply { gravity=Gravity.CENTER; setPadding(0,dp(10),0,0) }, lp(1f, 50))
        root.addView(tv("User এবং Operator পরিচালনা করুন", 17f, Color.GRAY).apply { gravity=Gravity.CENTER }, lp(1f, 34))
        val admin = Button(this).apply {
            text="⚙  Admin Control Panel"; textSize=17f; setTextColor(Color.WHITE); setBackgroundColor(purple)
        }
        root.addView(admin, lp(1f, 44))
        admin.setOnClickListener { adminPanel() }

        val refresh = TextView(this).apply {
            text="🔄  ডেটা প্রতি ২০ সেকেন্ড পর পর অটো রিলোড হচ্ছে\\nসর্বশেষ আপডেট: " +
                    SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())
            textSize=16f; gravity=Gravity.CENTER; setTextColor(Color.rgb(65,145,140))
            setPadding(dp(8),dp(8),dp(8),dp(8)); setBackgroundColor(Color.rgb(232,248,246))
        }
        root.addView(refresh, lp(1f, 72))
        root.addView(tv("মুন ডায়াগনস্টিক সেন্টার", 19f, Color.GRAY, true).apply { gravity=Gravity.CENTER; setPadding(0,dp(10),0,0) }, lp(1f, 38))
        root.addView(tv("আপনার বিশ্বস্ত স্বাস্থ্যসেবা কেন্দ্র", 15f, Color.GRAY).apply { gravity=Gravity.CENTER }, lp(1f, 28))

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addStat(g: GridLayout, icon:String, label:String, initial:String, status:String) {
        val box=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(14),0,dp(8),0); setBackgroundColor(Color.WHITE)
            setOnClickListener{ showList(status) }
        }
        val i=tv(icon, 32f, if(icon=="✕") Color.rgb(190,55,60) else if(icon=="✓") Color.rgb(40,145,105) else navy, false)
        val text=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL}
        text.addView(tv(initial,23f,navy,true)); text.addView(tv(label,16f,Color.DKGRAY,false))
        box.addView(i, LinearLayout.LayoutParams(dp(62),-1)); box.addView(text, LinearLayout.LayoutParams(0,-1,1f))
        val p=GridLayout.LayoutParams().apply{width=0;height=dp(58);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(dp(2),dp(2),dp(2),dp(2))}
        g.addView(box,p)
        db.collection("serials").get().addOnSuccessListener { s ->
            val n=s.documents.count{ status=="all" || it.getString("status")==status }
            text.removeAllViews(); text.addView(tv(n.toString(),23f,navy,true)); text.addView(tv(label,16f,Color.DKGRAY,false))
        }
    }

    private fun action(root:LinearLayout, label:String, fn:()->Unit) {
        val b=Button(this).apply{
            text=label; textSize=18f; setTextColor(Color.WHITE); setBackgroundColor(blue)
            setOnClickListener{fn()}
        }
        root.addView(b, lp(1f,43).apply{bottomMargin=dp(4)})
    }

    private fun addSerial() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),0)}
        val n=EditText(this).apply{hint="রোগীর নাম"}; val c=EditText(this).apply{hint="কেয়ার অফ নাম"}; val d=EditText(this).apply{hint="ডাক্তারের নাম"}
        box.addView(n,lp());box.addView(c,lp());box.addView(d,lp())
        AlertDialog.Builder(this).setTitle("অ্যাড সিরিয়াল").setView(box).setNegativeButton("বাতিল",null).setPositiveButton("সেভ"){_,_->
            db.collection("serials").add(mapOf("patientName" to n.text.toString(),"careOf" to c.text.toString(),"doctor" to d.text.toString(),"status" to "waiting","createdAt" to System.currentTimeMillis()))
                .addOnSuccessListener{toast("সিরিয়াল যোগ হয়েছে")}
        }.show()
    }

    private fun addSimple(title:String, collection:String) {
        val e=EditText(this).apply{hint="$title-এর নাম"}
        AlertDialog.Builder(this).setTitle("অ্যাড $title").setView(e).setNegativeButton("বাতিল",null).setPositiveButton("সেভ"){_,_->
            if(e.text.isNotBlank()) db.collection(collection).add(mapOf("name" to e.text.toString(),"createdAt" to System.currentTimeMillis()))
        }.show()
    }

    private fun chooseAndList(collection:String) {
        db.collection(collection).get().addOnSuccessListener { s ->
            val names=s.documents.mapNotNull{it.getString("name")}.toTypedArray()
            if(names.isEmpty()){toast("কোনো তথ্য নেই");return@addOnSuccessListener}
            AlertDialog.Builder(this).setTitle(if(collection=="doctors")"ডাক্তার নির্বাচন করুন" else "কেয়ার অফ নির্বাচন করুন")
                .setItems(names){_,which->showFiltered(collection,names[which])}.show()
        }
    }

    private fun showFiltered(collection:String,name:String) {
        val field=if(collection=="doctors")"doctor" else "careOf"
        db.collection("serials").whereEqualTo(field,name).get().addOnSuccessListener{s->
            val x=s.documents.joinToString("\n"){ "${it.getString("patientName")?:""} — ${it.getString("status")?:"waiting"}" }
            AlertDialog.Builder(this).setTitle("$name-এর সিরিয়াল").setMessage(if(x.isBlank())"কোনো সিরিয়াল নেই" else x).setPositiveButton("বন্ধ",null).show()
        }
    }

    private fun showList(status:String) {
        db.collection("serials").get().addOnSuccessListener{s->
            val x=s.documents.filter{status=="all"||it.getString("status")==status}.mapIndexed{i,d->
                "${i+1}. ${d.getString("patientName")?:""} | ${d.getString("doctor")?:""} | ${d.getString("status")?:""}"
            }.joinToString("\n")
            AlertDialog.Builder(this).setTitle("সিরিয়াল তালিকা").setMessage(if(x.isBlank())"কোনো তথ্য নেই" else x).setPositiveButton("বন্ধ",null).show()
        }
    }

    private fun adminPanel() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),0,dp(18),0)}
        val u=EditText(this).apply{hint="নতুন User/Operator নাম"}
        val r=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("User","Operator"))}
        box.addView(u,lp());box.addView(r,lp())
        AlertDialog.Builder(this).setTitle("Admin Control Panel").setView(box).setNegativeButton("বন্ধ",null).setPositiveButton("সেভ"){_,_->
            if(u.text.isNotBlank()) db.collection("users").document(u.text.toString()).set(mapOf("role" to r.selectedItem.toString(),"enabled" to true))
        }.show()
    }

    private fun base()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)}
    private fun tv(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply{text=s;textSize=size.toFloat();setTextColor(color);if(bold)setTypeface(typeface,1)}
    private fun lp(weight:Float=0f,height:Int=-2)=LinearLayout.LayoutParams(if(weight>0)0 else -1,height,weight).apply{bottomMargin=dp(2)}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
