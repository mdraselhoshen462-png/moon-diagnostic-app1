# Reference UI matching

এই সংস্করণে দেওয়া রেফারেন্স স্ক্রিনের কাঠামো অনুসরণ করা হয়েছে:
- MDC header
- স্বাগতম + Role
- লাল Logout bar
- আজকের তারিখ + date
- ছোট 2x2 statistic cards
- নীল full-width Quick Action bars
- ডাক্তার ওয়াইজ ও কেয়ার ওয়াইজ serial sections
- বেগুনি Admin Control Panel
- 20-second auto-refresh notice
- footer

নোট: বাংলা ফন্ট ও emoji rendering ফোনভেদে সামান্য পরিবর্তিত হতে পারে।
