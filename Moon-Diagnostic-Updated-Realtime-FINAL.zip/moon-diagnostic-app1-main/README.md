# Moon Diagnostic Center Android App

Updated UI and refresh behavior:
- Larger Login username/password fields and Login button.
- Larger dashboard statistics cards and action buttons.
- Dashboard shows a visible 20-second auto-refresh status and last-update time.
- Refresh timer runs only while the dashboard is visible and pauses in background.
- Admin-only User/Operator management remains protected by the current local role check.

Important: this source currently stores users/session data in SharedPreferences and the dashboard statistics are demo/local values. A Firebase project configuration (`google-services.json`) and Firebase Authentication/Firestore integration are still required for true shared multi-phone cloud data and real-time serial synchronization.
