# Moon Diagnostic Center — Updated Activity

এই ভার্সনটি `Moon-Diagnostic-APK-Updated-20sec.zip`-এর উপর ভিত্তি করে আপডেট করা হয়েছে।

## পরিবর্তন
- ২০ সেকেন্ডের Auto Refresh সম্পূর্ণ বাদ।
- উপর থেকে টেনে Refresh করার জন্য SwipeRefreshLayout যোগ করা হয়েছে।
- Firebase Realtime Database support যোগ করা হয়েছে। Firebase config না থাকলে অ্যাপ local fallback-এ চলবে।
- Dashboard/পেজে “Dashboard-এ ফিরে যান” বোতাম বাদ; Android Back button দিয়ে আগের পেজে যাওয়া যাবে।
- Total Serial-এর ভিতরে Doctor Wise ও Care Of Wise দুইটি tab।
- Doctor/Care Of নির্বাচন করলে আজকের সংশ্লিষ্ট সিরিয়াল দেখা যাবে। Filtered তালিকার display serial প্রতিদিন ১ থেকে শুরু হবে; বন্ধনীতে মূল global serial দেখাবে।
- Total Serial-এ নতুন সিরিয়াল যোগ করার বোতাম নেই।
- Add Serial পেজে অন্য সিরিয়ালের তালিকা নেই—শুধু নতুন সিরিয়াল যোগ করা যাবে।
- Doctor/Care Of selection list ব্যবহার করা হয়েছে।
- Admin থেকে Doctor/Care Of যোগ করা যাবে।
- Operator/Admin সিরিয়াল Complete, Edit ও Delete করতে পারবে; User পারবে না।
- Completed সিরিয়ালে Completed by ও সময় দেখাবে।
- Concurrent serial number-এর জন্য Firebase transaction ব্যবহার করা হয়েছে, তাই একই সময়ে একাধিক ফোন থেকে serial নেওয়ার সময় counter collision কমে।
- UI আগের অতিরিক্ত বড় সংস্করণের তুলনায় কিছুটা ছোট ও balanced করা হয়েছে।

## Firebase চালু করতে
1. Firebase Console-এ Realtime Database তৈরি করুন।
2. Android package name: `com.moondiagnostic.app` দিয়ে Android app যোগ করুন।
3. Firebase থেকে `google-services.json` ডাউনলোড করে `app/google-services.json` নামে রাখুন।
4. Root `build.gradle`-এ Google Services plugin যোগ করুন:
   `id 'com.google.gms.google-services' version '4.4.2' apply false`
5. App `build.gradle`-এর plugins অংশে যোগ করুন:
   `id 'com.google.gms.google-services'`
6. Firebase Realtime Database-এ প্রয়োজনীয় rules সেট করুন। Production ব্যবহারে Firebase Authentication + role-based Security Rules ব্যবহার করা উচিত।

## Default local admin
Firebase config না থাকলে local fallback-এ:
- Username: `admin`
- Password: `admin123`

প্রথম লগইনের পর production ব্যবহারের আগে admin credential পরিবর্তন/নিরাপদ করা উচিত।
